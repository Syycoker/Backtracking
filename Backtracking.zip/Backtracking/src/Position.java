
public class Position {
	public int x;
	public int y;
	
	public Position(int y, int x) {
		this.x = x;
		this.y = y;
	}
}
